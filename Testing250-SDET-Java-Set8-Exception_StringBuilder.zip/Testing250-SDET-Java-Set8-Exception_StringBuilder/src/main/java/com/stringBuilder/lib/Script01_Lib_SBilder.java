package com.stringBuilder.lib;

import java.util.Scanner;

public class Script01_Lib_SBilder {
	Scanner c = new Scanner(System.in);
	
	public StringBuilder CreateAStringBuilder(){
		
		String str = "Test automation framework";
		StringBuilder sb1 = new StringBuilder(str);
		
		return sb1;
		
	}
	
	public StringBuilder TakeInputForStringBuilder() {
		System.out.println("Enter the string value");
		String inp = c.nextLine(); //inp
		StringBuilder sb3 = new StringBuilder(inp);
		return sb3;
		
	}
	
	public StringBuilder Perform_Append_Builder() {
		
		System.out.println("Enter the string value");
		String inp1 = c.nextLine(); //inp
		StringBuilder sb5 = new StringBuilder(inp1);
		
		sb5.append(78.0);
		
		return sb5;
			
	}
	
	public void StringBuilderEqualityCheck() {
		StringBuilder s1 = new StringBuilder("Testdata");
		StringBuilder s2 = new StringBuilder("Testdata");
		
		String ss1 = s1.toString();
		String ss2 = s2.toString();
		
		if(ss1.equalsIgnoreCase(ss2)){
			System.out.println("same data");
		}
		
	
	}
	
	
	public void SubStringInBuilder() {
		StringBuilder sb8 = new StringBuilder("Test data are well documnented");
		
		String str1 = sb8.toString();
		boolean b = str1.contains("data");
		
		System.out.println(b);
	}
	
	
	public void Reverse_StringBuilder() {
		StringBuilder sb9 = new StringBuilder("Hello World !");
		StringBuilder reversedata = sb9.reverse();
		System.out.println(reversedata);
		
		
	}
	
	
	public void insertData() {
		StringBuilder sb10 = new StringBuilder("Hello World !");
		sb10.insert(6, "new content");
		
		System.out.println(sb10);

		
	}
	
	public void DeleteData() {
		StringBuilder sb11= new StringBuilder("Hello World !");
		
		sb11.delete(5, 10);
		System.out.println(sb11);
		
		//hashcode
		//lastIndexOf
		//length
		//insert and delete at char index

		
	}
	
	public void testmethods() {
		int a = 5;
		int b = 2;
		System.out.println(a/b);
		
	}
	
	public void insertAtCharIndex() {
		StringBuilder sb10 = new StringBuilder("Test Data One");
		sb10.insert(5,'G');
		System.out.println(sb10);
	}
	
	public void deleteFromCharIndex() {
		StringBuilder sb11 = new StringBuilder("Test Data One");
	    sb11.deleteCharAt(6);
	    System.out.println(sb11);
	}
}
	
	



