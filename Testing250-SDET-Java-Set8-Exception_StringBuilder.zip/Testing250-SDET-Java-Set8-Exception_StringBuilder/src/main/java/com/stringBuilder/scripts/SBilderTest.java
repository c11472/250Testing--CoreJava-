package com.stringBuilder.scripts;

import com.stringBuilder.lib.Script01_Lib_SBilder;

public class SBilderTest {
	public static void main(String[] args) {
		Script01_Lib_SBilder obj = new Script01_Lib_SBilder();
		
		
		StringBuilder sb2= obj.CreateAStringBuilder();
		System.out.println("the stringbuilder is sb2: " + " " + sb2);
		
		
		
		StringBuilder sb4=obj.TakeInputForStringBuilder();
		System.out.println("The data is sb4: " + " " + sb4);
		
		
		StringBuilder sb6 = obj.Perform_Append_Builder();
		System.out.println("Append output : " + sb6);
		
		
		obj.StringBuilderEqualityCheck();
		
		obj.SubStringInBuilder();
		
		obj.Reverse_StringBuilder();
		
		obj.insertData();
		
		obj.DeleteData();
		obj.testmethods();
		
		obj.insertAtCharIndex();
		obj.deleteFromCharIndex();
	}	

}
