package PropertiesFileRead;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ReadDataFromProperties {
	
	public static void main(String[] args) throws IOException {
		
		ReadDataFromProperties obj = new ReadDataFromProperties();
		obj.ReadDataProperties();
		
	}
	
	public void ReadDataProperties() throws IOException {
		
		String filePath = "E://data1.properties";
		
		FileReader fr = new FileReader(filePath);
		
	    // Create the Properties object
		
		Properties p = new Properties();
		
		p.load(fr);
		
		String data2 = p.getProperty("Color");
		System.out.println(data2);
		
		
		String data3 = p.getProperty("Fruite");
		System.out.println(data3);
		
	}

}
