package com.bookclass.two;

import java.util.Scanner;

import com.bookinterfaces.one.Author;
import com.bookinterfaces.one.Publisher;

public class BookClassOne  implements Publisher , Author{
    Scanner c=new Scanner(System.in);
    //String authorName;
	public String AuthorNameData() {
		System.out.println("Enter author name");
		String authodName=c.next();
		
		return authodName;
	}

	public int AuthorIDData() {
		// TODO Auto-generated method stub
		System.out.println("Enter author id");
		int authid =c.nextInt();
		return authid;
		
	}

	public double AuthorRemunerationDetails() {
		// TODO Auto-generated method stub
		System.out.println("Authod remuneration");
		double remunerationdata = c.nextDouble();
		return remunerationdata;
	}

	public int AuthorExpDetails() {
		// TODO Auto-generated method stub
		System.out.println("Enter author's exp");
		int expinyrsauth=c.nextInt();
		return expinyrsauth;
	}

	public String publisherNameData() {
		// TODO Auto-generated method stub
		System.out.println("Enter publisher name:");
		String punname =c.next();
		return punname;
	}

	public int publisheridData() {
		// TODO Auto-generated method stub
		System.out.println("Enter publisher id");
		int pid=c.nextInt();
		return pid;
	}

	public String publisherOwnerData() {
		System.out.println("Enter publisher owner");
		// TODO Auto-generated method stub
		String pownernm = c.next();
		return pownernm;
	}

	public int publisherExperienceData() {
		// TODO Auto-generated method stub
		System.out.println("Enter publisher exp:");
		int pexpd = c.nextInt();
		return pexpd;
	}

	
}
