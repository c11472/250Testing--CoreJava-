package com.bookinterfaces.one;

public interface Author {
	
		abstract	String AuthorNameData();
		abstract	int AuthorIDData();
		abstract	double AuthorRemunerationDetails();
		abstract	int AuthorExpDetails();
	    static int test1(int p) {
	    	//System.out.println("we are in test1");
	    	return p;
	    	
	    }
		
		// defining method
		default void test() {
			System.out.println("we are in test");
			
		}
		


}
