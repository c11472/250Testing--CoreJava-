package com.bookinterfaces.one;

public interface Publisher {
	
	 abstract  String  publisherNameData();
	 abstract  int publisheridData();
	 abstract  String publisherOwnerData();
	 abstract int publisherExperienceData();
}
