package com.bookcaseint.runner;

import com.bookclass.two.BookClassOne;
import com.bookinterfaces.one.Author;

public class BookPubAuthRunner extends BookClassOne {
	
	public static void main(String[] args) {
		
		// Publisher
		
		BookPubAuthRunner testobj = new BookPubAuthRunner();
		String pnm =testobj.publisherNameData();
		int pid=testobj.publisheridData();
		String pond=testobj.publisherOwnerData();
		int pexp=testobj.publisherExperienceData();
		
		// Extract the data
		System.out.print(pnm + " " + pid+ " "+pond+ " "+pexp);
		
		// Author
		String anm=testobj.AuthorNameData();
		int aid=testobj.AuthorIDData();
		double arem=testobj.AuthorRemunerationDetails();
		int aexp=testobj.AuthorExpDetails();
		
		// Extract the data
		System.out.print(anm+ " "+ aid+ " " + arem+ " " + aexp);
		
		
		
		int p1=Author.test1(67);
		System.out.println(p1);
		
		testobj.test();
		
		
		
			
		}
	}


