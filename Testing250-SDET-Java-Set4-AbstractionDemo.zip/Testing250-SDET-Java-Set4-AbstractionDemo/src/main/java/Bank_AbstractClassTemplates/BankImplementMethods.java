package Bank_AbstractClassTemplates;

import java.util.Scanner;

class BankImplementMethods extends BankAbsTemplate1 {
	Scanner c = new Scanner(System.in);

	void BankName(String BankName) {
		//Scanner c = new Scanner(System.in);
		System.out.println("Enter the nbank name :");
		BankName = c.nextLine();
		System.out.println("The bank name is :" +" "+BankName);
		
	}

	String BankCEOName(String CEONm) {
		// TODO Auto-generated method stub
		System.out.println("Enter CEO's Name");
		CEONm=c.nextLine();
		return CEONm;
		
	}

	String BankAddress(String bnkaddr) {
		System.out.println("Enter Bank address");
		bnkaddr = c.nextLine();
		return bnkaddr;
	}

	int BankIFSCCode(int ifscc) {
		// TODO Auto-generated method stub
		System.out.println("Enter IFSC Code for the bank");
		
		ifscc=c.nextInt();
		return ifscc;
	}

	double BankTurnOverPerYear(double turnover) {
		// TODO Auto-generated method stub
		System.out.println("Enter the turnover per year-2024-2025");
		turnover=c.nextDouble();
		
		return turnover;
	}

}
