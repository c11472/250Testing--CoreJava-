package Bank_AbstractClassTemplates;

public class RunmainBank {
	public static void main(String[] args) {
		
		// Create the object for class BankImplementMethods
		
		BankImplementMethods banktest = new BankImplementMethods();
		banktest.BankName("abc");
		String baddr=banktest.BankCEOName("def");
		int ifc=banktest.BankIFSCCode(1);
		double tov=banktest.BankTurnOverPerYear(1900.00);
		String addrb=banktest.BankAddress("unit1");
		
		System.out.println(baddr);
		System.out.println(ifc);
		System.out.println(tov);
		System.out.println(addrb);
		
		// Changes 
		
		banktest.testmethod();
		
		
		String mnm=banktest.ModeleName("Model-101");
		System.out.println("MOdel name is :" + mnm);
	}

}
