package Bank_AbstractClassTemplates;

public abstract class BankAbsTemplate1 
    {
	abstract void BankName(String BankName);
	abstract String BankCEOName(String CEONm);
	abstract String BankAddress(String bnkaddr);
	abstract int BankIFSCCode(int ifscc);
	abstract double BankTurnOverPerYear(double turnover);
	
	// Adding Changes after receiving from client in between the dev phase
	// These changes added from Java-8 onwards
	
	void testmethod() {
		System.out.println("Hello , we are in testmethod !");
	}
	


	}
