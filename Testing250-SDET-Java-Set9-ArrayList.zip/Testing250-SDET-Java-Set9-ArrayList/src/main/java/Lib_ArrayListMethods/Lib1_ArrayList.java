package Lib_ArrayListMethods;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Lib1_ArrayList {
	
	Scanner c = new Scanner(System.in);
	
	public void CreateAnArrayList() {
		ArrayList<Integer> al = new ArrayList();
		
		al.add(109);
		al.add(200);
		al.add(45);
		al.add(-78);
		// Display the arraylist
		System.out.println(al);
	}
	
	// Method returning ArrayList
	
	public ArrayList CreateAnArrayListTest() {
		ArrayList<Integer> al = new ArrayList();
		
		al.add(109);
		al.add(200);
		al.add(45);
		al.add(-78);
		// Display the arraylist
		return al;
	}
	
	// Take input for an arrayList
	
	public ArrayList TakeInputForArrayList() {
		ArrayList<Integer> al1 = new ArrayList();
		int i;
		for( i=0;i<10;i++) {
			al1.add(c.nextInt());
		}
		
		
		
		int p = al1.get(0); //1 -- get method
		System.out.println(p);
		System.out.println(al1.size());
		return al1;	
		
	}
	
	
	public void JointTwoArrayLists() {
		
		List<Integer> l1 =  Arrays.asList(1,2,3,4,5);
		System.out.println(l1);
		
	}
	
	// Join two arrayList
   public ArrayList JointTwoArrayListsTest() {
	
	ArrayList alp1 = new ArrayList(Arrays.asList(1,2,3,4,5));
	
	ArrayList alp2 = new ArrayList(Arrays.asList(11,22,33,44,55));
	
	alp1.addAll(alp2);

	
	return alp1;
		
   }


   public ArrayList TakeDataFromArrayToList() {
	ArrayList<Integer> al9 = new ArrayList();
	
	
    int ip[] = {99,205,14,23,25,101};
    
    for(int i = 0;i<=ip.length-1;i++) {
    	al9.add(ip[i]);
    }
   
	
	return al9;
}
 // Restrict ArrayList with capacity  
   public ArrayList ArrayListWithCapacity() {
	   ArrayList plp = new ArrayList();
	   
	   int arr2[] = {1,2,3,4,5,6,7,8,9,10,11};
	   int capacity=5;
	   
	   for(int i=0;i<=arr2.length-1;i++) {
		   if(i<=capacity) {
			  plp.add(arr2[i]);		  
		   }    
	   }
	   
	   plp.add(999);
	   
	  return plp;
   }
   
   
// Copy data from one arrayList to other 
	
	public ArrayList CopyData() {
		ArrayList ap1 = new ArrayList(Arrays.asList(1,2,3,4,5));

		ArrayList <Integer> ap2 = new ArrayList(ap1);
		return ap2;
	}
	
	
	// Use Iterator
	public void ArrayListTraversalOne() {
		
		ArrayList ap3 = new ArrayList(Arrays.asList(11,12,13,14,15));
		
		// Traverse the arrayList using Iterator
		
		Iterator it = ap3.iterator();
		
		// Traverse
		
		//it.hasNext();
		//it.next();
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}
		
		
	}
	
	
	// Use enhanced forloop to traverse the arrayList
	
	public void ArrayListTraversalTwo() {
		ArrayList <Integer> ap4 = new ArrayList(Arrays.asList(111,122,133,144,155));
		
		for(int i:ap4) {
			System.out.print(i + " ");
		}
	
		
	}
	
	public int RandomDataAccessFromArrayList() {
		
		ArrayList <Integer> ap5 = new ArrayList(Arrays.asList(10,90,45,12,15));
		
		int res = ap5.get(2); // 45
		return res;

		
		
	}
	// Inserting data
	public ArrayList InsertDataInList() {
		ArrayList <Integer> ap6 = new ArrayList(Arrays.asList(111,122,133,144,155));
		
		ap6.add(ap6.size()-1, 9898);
		
		
        return ap6;
	}
	
	// Update the data in ArrayList
	
	public ArrayList UpdateTheData() {
		ArrayList <Integer> ap7 = new ArrayList(Arrays.asList(111,122,133,144,155));
		ap7.set(2,947);
        return ap7;
    
		
	}
	
	
	// Delete the data from ArrayList
	
	public ArrayList DeleteTheData() {
		ArrayList <Integer> ap8 = new ArrayList(Arrays.asList(111,122,133,144,155));
        ap8.remove(4);
        return ap8;
		
	}
	
	// Validation
	public boolean ValidateDataInArrayList() {
		ArrayList <Integer> ap8= new ArrayList(Arrays.asList(111,122,133,144,155));
        if(ap8.contains(144)) {
        	return true;
        }
        else {
        	return false;
        }
		
	}
	
	public Object[] ConvertDataToArray() {
		
		ArrayList <Integer> ap7 = new ArrayList(Arrays.asList(111,122,133,144,155));

		Object rest[] = ap7.toArray();
		
		return rest;
	}
	
	
	//Sort the data in ArrayList
	
	public ArrayList SortTheDataInArrayList() {
		ArrayList <Integer> ap8 = new ArrayList(Arrays.asList(10,56,45,23,17,99,142));
		Collections.sort(ap8);	
		return ap8;
	}
	
	//searching element
	
	public int SearchElementInArrayList() {
		ArrayList <Integer> ap9 = new ArrayList(Arrays.asList(10,56,45,23,17,99,142));
		
		Collections.sort(ap9);
		int index = Collections.binarySearch(ap9,23);
		return index;	
	}
}
