package Script_ArrayList;

import java.util.ArrayList;
import java.util.Arrays;

import Lib_ArrayListMethods.Lib1_ArrayList;

public class TestArrayList001 {
	
	public static void main(String[] args) {
		Lib1_ArrayList obj = new Lib1_ArrayList();
		obj.CreateAnArrayList();
		
		
		// Call a method which returns ArrayList
		
		ArrayList al3 = obj.CreateAnArrayListTest();
		System.out.println("The list values are :" + " " + al3);
		
		ArrayList al5=obj.TakeInputForArrayList();
		//System.out.println("The input for list stored:" + " " + al4);
		
	     obj.JointTwoArrayLists();
	     ArrayList alp2 = obj.JointTwoArrayListsTest();
	     System.out.println(alp2);
	     
	     ArrayList al10=obj.TakeDataFromArrayToList();
	     System.out.println(al10);
	     
	     ArrayList al11 = obj.ArrayListWithCapacity();
	     System.out.println(al11);
	     
	     ArrayList plp1 = obj.ArrayListWithCapacity();
	     System.out.println(plp1);
	     
	     ArrayList plp2 = obj.CopyData();
	     System.out.println(plp2);
	     
	     obj.ArrayListTraversalOne();
	     
	     obj.ArrayListTraversalTwo();
	     System.out.println();
	     int res1=obj.RandomDataAccessFromArrayList();
	     System.out.println(res1); // op
	     
	     ArrayList p5 = obj.InsertDataInList();
	     System.out.println(p5);
	     
	     ArrayList p6 = obj.UpdateTheData();
	     System.out.println(p6);
	     ArrayList p7 = obj.DeleteTheData();
	     System.out.println(p7);
	     
	     boolean resultv = obj.ValidateDataInArrayList();
	     
	     System.out.println("The lement is present in list" + resultv);
	     
	     
	     Object ares[] = obj.ConvertDataToArray();
	     
	     for(Object i:ares) {
	    	 System.out.print(i + " ");
	     }
	     
	     System.out.println("The length of the array: "  + ares.length);	     
	     
	     // sort the data in array list
	     
	     ArrayList pp1 = obj.SortTheDataInArrayList();
	     System.out.println("after sort elements : " + " " + pp1);
	     
	     
	     int indexofel = obj.SearchElementInArrayList();
	     System.out.println(indexofel);
	}	
	
}



