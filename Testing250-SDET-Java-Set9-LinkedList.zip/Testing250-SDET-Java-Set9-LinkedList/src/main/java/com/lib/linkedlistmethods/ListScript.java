package com.lib.linkedlistmethods;

import java.util.List;

import com.lib.linkedlistscripts.ListLib;

public class ListScript {
	public static void main(String[] args) {
		ListLib l1 = new ListLib();
		
		List result=l1.CreateAList();
		System.out.println(result);
		
	}

}
