package com.lib.linkedlistmethods;

import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class LinkedMethods {
	
	public LinkedList ThisIsALinkedList() {
		
		LinkedList<Integer> l = new LinkedList(Arrays.asList(10,20,45,12,5));
		
		return l;
	
		
	}
	
	
	public LinkedList LoadDataInLinkedList() {
		
		LinkedList <String> cities = 
				new LinkedList();
		cities.add("BBSR");
		cities.add("Pune");
		cities.add("Noida");
		cities.add("HYD");
		cities.add("CHENNAI");
		cities.add("Kochin");
		
		LinkedList city = new LinkedList(cities);
		return city;
		

	}
	
	public LinkedList AddFirstDemo() {
		LinkedList <Integer>ll1 = new LinkedList(Arrays.asList(10,45,2,39,78,90));
		ll1.addFirst(101);
		return ll1;
	}
	
	public LinkedList AddTwoLists() {
		LinkedList <Integer> la1 = new LinkedList(Arrays.asList(1,4,2,3,7,9));
		LinkedList <Integer> la2 = new LinkedList(Arrays.asList(11,41,21,31,71,91));
		
		la1.addAll(la2);
		
		
		return la1;
			
	}
	
	//Traverse the linkedlist
	
	public void TeaverseTheLinkedList() {
		LinkedList <Integer> la3 = new LinkedList(Arrays.asList(11,41,21,31,71,91));
		
		Iterator it = la3.iterator();
		
		while(it.hasNext()) {
			System.out.println(it.next());
		}

	}
	
	public void DescenndingIteratorDemo() {
		
		LinkedList <Integer> la4 = new LinkedList(Arrays.asList(11,41,21,31,71,91));
		
		Iterator it1 = la4.descendingIterator();
		
		while(it1.hasNext()) {
			System.out.println(it1.next());
			
		}

		
	}
	
	public void Peakdemo() {
		LinkedList <Integer> la4 = new LinkedList(Arrays.asList(11,41,21,31,71,91));
        System.out.println(la4.peekFirst()); //11
        System.out.println(la4.peek()); // 11
        System.out.println(la4.peekLast()); //91
        
        
        
	}
	
	public LinkedList CloneTheList() {
		LinkedList <Integer> la5 = new LinkedList(Arrays.asList(11,41,21,31,71,91));
		LinkedList <Integer> la6 = (LinkedList<Integer>) la5.clone();
		return la6;	
	}
	
	public LinkedList PollData() {
		LinkedList <Integer> la7 = new LinkedList(Arrays.asList(11,41,21,31,71,91));
		
		la7.poll();
		
		return la7;
		
		

		
	}
	
	
	public LinkedList PollLastDemo() {
		LinkedList <Integer> la8 = new LinkedList(Arrays.asList(11,41,21,31,71,91));
        la8.pollLast();
       
        return la8;
		
	}
	
	public LinkedList EmptyCheck() {
		
		LinkedList <Integer> la9 = new LinkedList(Arrays.asList(99));
        if(la9.isEmpty()) {
        	la9.add(19);
        	la9.add(20);
        	la9.add(31);
        	//System.out.println("Elements loaded" + " " + la9);
        	
        
        	
        }
        else {
            System.out.println(la9);
        }
        
        return la9;
        
        
        
        
	}
	
	
	public int elementDemo() {
		LinkedList <Integer> la10 = new LinkedList(Arrays.asList(11,41,21,31,71,91));
        int res1=la10.element();
        System.out.println(la10);
        return res1;// 11
	}
	
	public LinkedList SetMethodDemoList() {
		
		LinkedList <Integer> la11 = new LinkedList(Arrays.asList(11,41,21,31,71,91,9,45,23,32,59));
        la11.set(5, 999);
        
        return la11;
		
	}
	
	
	public LinkedList TakeInputLinkedList() {
		Scanner c = new Scanner(System.in);
		
		LinkedList<Integer> list5 = new LinkedList<Integer>();
		
		for(int i=0;i<=5;i++) {
			list5.add(c.nextInt());
		}
		//list5.to
		
		return list5;
		
	}
	
	
	public  Object[] ConvertLinkedListToArray() {
		LinkedList <String> listdemo = new LinkedList(Arrays.asList("mumbai","chennai","Delhi","Kolkata"));
		Object arr[] = listdemo.toArray();
		
	     
		return arr;
	}
	
	
	

}
