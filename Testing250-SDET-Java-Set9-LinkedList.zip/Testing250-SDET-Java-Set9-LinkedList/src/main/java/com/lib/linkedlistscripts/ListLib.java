package com.lib.linkedlistscripts;

import java.util.Arrays;
import java.util.List;

public class ListLib {
	
	public List CreateAList() {
		
		List <Double> sal = 
				Arrays.asList(45000.00 , 43000.90,76000.56,34000.80);
	    
		return sal;
		
		
		
	}

}
