package com.lib.linkedlistscripts;

import java.util.LinkedList;

import com.lib.linkedlistmethods.LinkedMethods;

public class LikedListScript001 {
	public static void main(String[] args) {
		LinkedMethods obj = new LinkedMethods();
		
		LinkedList resList1=obj.ThisIsALinkedList();
		
		System.out.println(resList1);
		
		
		LinkedList list2=obj.LoadDataInLinkedList();
		System.out.println(list2);
		
		
		LinkedList list3 = obj.AddFirstDemo();
		System.out.println(list3);
		
		// add all
		
		
		
		LinkedList list4 = obj.AddTwoLists();
		
		System.out.println(list4);
		
		obj.TeaverseTheLinkedList();
		
		obj.DescenndingIteratorDemo();
		
		obj.Peakdemo();
		
		LinkedList l3 =obj.CloneTheList();
		System.out.println("cloned list"+ " " + l3);
		
		LinkedList l4=obj.PollData();
		System.out.println("Poll first element" + l4);
		
		
		LinkedList l5 = obj.PollLastDemo();
		System.out.println("Remove the last element" + l5);
		
		
		LinkedList l6 = obj.EmptyCheck();
		System.out.println(l6);
		
		int res4=obj.elementDemo();
		System.out.println("Element output" + res4);
		
		LinkedList res5 = obj.SetMethodDemoList();
		System.out.println("Set method" + res5);
		
		
		LinkedList lis6 = obj.TakeInputLinkedList();
		System.out.println(lis6);
		
		Object p[] = obj.ConvertLinkedListToArray();
		System.out.println("Traverse the object array");
		
		for(Object i:p) {
			System.out.print(i+ " ");
		}
		
		
		
		
		
	}
	

}
