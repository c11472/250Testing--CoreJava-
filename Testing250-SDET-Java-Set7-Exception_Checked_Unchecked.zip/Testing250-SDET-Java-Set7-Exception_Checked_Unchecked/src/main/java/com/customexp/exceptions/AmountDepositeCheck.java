package com.customexp.exceptions;

import java.util.Scanner;

import CustomExceptionsPackage.InsufficientAccountException;

public class AmountDepositeCheck {
	
	
	//create the static method for validating the amount
	public static void main(String[] args) throws InsufficientAccountException {
		//invoke the method - static method
		
		AmountDepositeCheck testexp1 = new AmountDepositeCheck();
		
		validateAmount();
		

	}
	
	public static void validateAmount() throws InsufficientAccountException {
		//perform validation.
		
		double depositamt;
		Scanner c = new Scanner(System.in);
		
		System.out.println("Enter the amount you need to deposit");
		depositamt = c.nextDouble();
		//validate
		if (depositamt<5000.00) {

		throw new InsufficientAccountException("Invalid amount entered !");

		//throw new ExceptionClassCustomName(“Exception message”)
		}
		else{
			
		   System.out.println("Account created successfully ! Thank You");
		//
		}
		
		}//method end


}
