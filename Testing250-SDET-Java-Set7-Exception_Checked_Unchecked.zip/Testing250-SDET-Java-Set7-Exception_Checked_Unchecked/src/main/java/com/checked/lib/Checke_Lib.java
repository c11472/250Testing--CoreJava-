package com.checked.lib;

import java.util.Scanner;

public class Checke_Lib {
	Scanner c = new Scanner(System.in);
	
	//int arr[] = {1,2,3,4,5};
	
	// Demo - NulllPointerException
	public boolean StringEqualsTest(String str1,String str2) {
	   if(str1.contains(str2)) {
		   return true;
	   }
	   else {
		   return false;
	   }
	}
	
	
	// InputMissMatchException
	
	public double InputMismatchExpDemo(double val) {
	    System.out.println("Enter the decimal value for val");
	    val = c.nextDouble();
		return val;
		
	}
	
	// ArithmeticException
	
	public int ArithmeticExceptionDemo(int inp) {
		int result = inp/0;
		return result;
	}
	
	// ArrayIndex
	
	public int arrayTest(int arr[]) {
		
		
		
		return  arr[8];
	}
	
	public void DisplayData() {
		System.out.println("hello these are unchecked exceptions");

	}
	
		
	}
	

