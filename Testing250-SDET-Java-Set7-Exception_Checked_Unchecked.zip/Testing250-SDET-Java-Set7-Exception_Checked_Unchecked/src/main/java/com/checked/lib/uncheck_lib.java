package com.checked.lib;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class uncheck_lib {
	
	public void ReadFile() throws FileNotFoundException {
		
		String path = "C://test1//file1.txt";
		
		FileReader fr = new FileReader(path);
		
		
	}
	
	// JDBC Connection - sql 
	// checked Exceptions
	// excel read write 
	// properties , xml , csv file reading 

}
