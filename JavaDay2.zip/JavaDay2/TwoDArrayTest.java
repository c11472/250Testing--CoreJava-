package com.testing250.JavaDay2;

public class TwoDArrayTest {
	public static void main(String[] args) {
		
		Day2Lib obj = new Day2Lib();
		obj.TwoDArray();
		
	}

}
