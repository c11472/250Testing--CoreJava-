package com.customexp.exceptions;

public class InsufficientAccountException extends Exception {
	
	public InsufficientAccountException(String msg1){
		super(msg1);
		
	}

}

