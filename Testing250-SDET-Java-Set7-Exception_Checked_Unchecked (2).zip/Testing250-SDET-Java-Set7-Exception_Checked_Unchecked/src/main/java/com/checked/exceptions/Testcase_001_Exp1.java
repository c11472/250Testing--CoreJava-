package com.checked.exceptions;



import java.util.Scanner;

import com.checked.lib.Checke_Lib;

public class Testcase_001_Exp1 {
	public static void main(String[] args) {
		Checke_Lib obj = new Checke_Lib();
		
	try {
		boolean res1=obj.StringEqualsTest("test",null);
		System.out.println(res1);
	}
	catch(Exception e) {
		e.printStackTrace();
		System.out.println("hello");
	}
		
		
	try {	
		double res2 = obj.InputMismatchExpDemo(78);
		System.out.println(res2);
	}
	catch(Exception e1){
		e1.printStackTrace();
	}
		
	try{
		int res1 = obj.ArithmeticExceptionDemo(100);
	
		System.out.println(res1);
	}
	catch(Exception e2) {
		e2.printStackTrace();
	}
	try {	
		int arr[] = {1,2,3,4,5};	
		int res4 = obj.arrayTest(arr);
		System.out.println(res4); 
	}
	
	finally {
		System.out.println("hello testers !"); //
		}
		
	/*catch(Exception e6) {
		System.out.println("hello There !");
	}*/
	try {
		int n;
		Scanner c1= new Scanner(System.in);
		n=c1.nextInt();
		System.out.println(n);
	}

	finally {
	obj.DisplayData(); //
	}

}
}
