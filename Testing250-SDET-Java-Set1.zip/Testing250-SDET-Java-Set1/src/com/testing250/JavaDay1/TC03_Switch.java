package com.testing250.JavaDay1;

import java.util.Scanner;

import com.testing250.JavaDay1Lib.Testing250Lib;

public class TC03_Switch {
	public static void main(String[] args) {
		Testing250Lib obj = new Testing250Lib();
		
		//Scanner
		
		Scanner c = new Scanner(System.in);
		System.out.println("Enter the case index : ");
		int CaseInd = c.nextInt();
		
		switch(CaseInd) {
		case 1:
			
			double CircleArea=obj.CalculateareaOfCircle(5.0, 3.141);
			System.out.println(CircleArea);
			break;
			
		case 2:
			obj.CalculateFactorial(5);
			break;
		case 3:
			int x[] = {10,20,30,40,50};
			int resultArr[]=obj.display(x);
			for(int i:resultArr) {
				System.out.print(i + " ");
			}
			
			break;
		
		
		
		case 4:
			double salg=obj.GrossCalculate(78000.00);
			System.out.println(salg);
			break;
		case 5:
			obj.PrintNumber(78);
			break;
			
			
		default:
			System.out.println("Invalid case index ");
			
	}

 }
}
