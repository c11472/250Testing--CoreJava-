package com.testing250.JavaDay1;

public class testMethodDelete {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		testMethodDelete o1 = new testMethodDelete();
		o1.SayHello();

	}
	
	
	public void SayHello() {
		
		System.out.println("Hello World !");
		
	}

}
