package com.testing250.JavaDay1;

import java.util.Arrays;
import java.util.List;

import com.testing250.JavaDay1Lib.Testing250Lib;

public class TC02_CallMethods {
	// Driver code
	// call the methods from lib
	public static void main(String[] args) {
		
		// Create an object
		// className ObjectName = new className();
		
		Testing250Lib test1 = new Testing250Lib();

		
		String data =test1.ReverseString("helloworld");
		System.out.println(data);
		
		test1.SayHello();
		
		
		double gs = test1.GrossCalculate(28000.00);
		
		System.out.println(gs);
		
		
		test1.CalculateFactorial(5);
		double ar=test1.CalculateareaOfCircle(6.0, 3.141);
		
		System.out.println(ar);
		int c[] = {1,2,3,4,5}; // Load the data
		int brr[] = test1.display(c);
		
		for(int i:brr) {
			System.out.println(i);
		}
		List l2 = Arrays.asList(10,20,30,40,50);
		List L1 = test1.Data( l2);
		System.out.println(L1);
		
		
	}

}
