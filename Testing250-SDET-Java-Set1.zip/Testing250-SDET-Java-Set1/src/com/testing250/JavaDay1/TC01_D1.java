package com.testing250.JavaDay1;


// Template Code

public class TC01_D1 {

	public static void main(String[] args) { // main method
		// TODO Auto-generated method stub
		
		// Say hello
		System.out.println("Hello There !");
		System.out.println("testing 250");
		System.out.print("testing 250");

	

	}

}
