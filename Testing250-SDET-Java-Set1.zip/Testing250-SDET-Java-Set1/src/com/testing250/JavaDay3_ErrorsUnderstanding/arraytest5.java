package com.testing250.JavaDay3_ErrorsUnderstanding;

public class arraytest5 {
	public static void main(String[] args) {
	String res = null;
	System.out.println(res+899);
	}

}
