package com.testing250.JavaDay3_ErrorsUnderstanding;

import java.util.Scanner;

public class Test1 {
	
   public static void main(String[] args) {
	   String name;
	   Scanner c = new Scanner(System.in);
	   name=c.nextLine();
	   System.out.println(name);  // QA Testing 250
	
}
}

