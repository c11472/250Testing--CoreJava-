package com.testing250.JavaDay3_ErrorsUnderstanding;

public class attarytest1 {
	
	public static void main(String[] args) {
		
		Object arr[] = {1,"test",67,'a'};
		for(int i=0;i<=arr.length-1;i++) {
			System.out.println(arr[i]);
		}
		
	}

}
