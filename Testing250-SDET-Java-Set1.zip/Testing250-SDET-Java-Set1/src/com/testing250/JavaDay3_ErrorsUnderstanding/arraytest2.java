package com.testing250.JavaDay3_ErrorsUnderstanding;

public class arraytest2 {
	public static void main(String[] args) {
		int arr[] = new int[5];
		for(int i:arr) {
			System.out.print(i + "**");
		}
	}

}
