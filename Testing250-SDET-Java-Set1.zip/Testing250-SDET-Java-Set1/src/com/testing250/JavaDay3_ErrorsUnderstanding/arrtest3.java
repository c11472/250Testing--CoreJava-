package com.testing250.JavaDay3_ErrorsUnderstanding;

public class arrtest3 {
	public static void main(String[] args) {
		char num =' ';
		System.out.println(num);
	}

}
