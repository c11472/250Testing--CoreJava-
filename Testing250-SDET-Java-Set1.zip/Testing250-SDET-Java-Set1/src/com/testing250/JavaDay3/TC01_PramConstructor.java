package com.testing250.JavaDay3;

public class TC01_PramConstructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Invoking constructor
		
		EmployeeData obj = new EmployeeData("Amit J", "QA Testing", "Raghavan S", 47000.00, 11472);
		
		System.out.println(obj.Ename + " "+ obj.HRName + " " + obj.Dept + " " + obj.Sal + " " + obj.Eid);
		
		EmployeeData obj1 = new EmployeeData("Gayatri M", "SDET ", "Shiv P", 87900.00, 11473);
		System.out.println(obj1.Ename + " "+ obj1.HRName + " " + obj1.Dept + " " + obj1.Sal + " " + obj1.Eid);
		
	}
	
	}


class EmployeeData{
	String Ename,Dept,HRName;
	double Sal;
	int Eid;
	
	EmployeeData(String en , String dep , String hrnm , double sl , int id){
		this.Ename = en;
		this.Dept=dep;
		this.HRName=hrnm;
		this.Sal=sl;
		this.Eid=id;
		
	}
}