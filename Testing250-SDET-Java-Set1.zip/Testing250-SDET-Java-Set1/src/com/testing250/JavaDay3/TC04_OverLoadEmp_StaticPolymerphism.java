package com.testing250.JavaDay3;

import java.util.Scanner;

public class TC04_OverLoadEmp_StaticPolymerphism {
	
	
	public static void main(String[] args) {
		
		// object
		EmployeeOne obj = new EmployeeOne();
		obj.EmpDetails();
		
		obj.EmpDetails("testuseremp");
		obj.EmpDetail("user45", 786876);
				
	}

}

class EmployeeOne{
	
	String EmpName;
	int EmpId;
	double EmpSal;
	String EmpDept;
	
	// Constructor
	
	EmployeeOne(){
		EmpName = "Tammanha";
		EmpId = 5643;
		EmpSal = 67000.00;
		EmpDept= "HRD";	
	}
	// method
	public void EmpDetails() {
		System.out.println("The EmpName is : " + " " + EmpName);
	}
	
	public void EmpDetails(String enm) {
		//System.out.println("The Employee name is : " + EmpName);
		Scanner c = new Scanner(System.in); c = new Scanner(System.in);
		
		enm = c.nextLine();
		System.out.println(enm);
		
		
	}
	
	public void EmpDetail(String emp1 ,int empid) {
		
		emp1 = "prachi mis";
		empid = 7865;
		System.out.println(emp1 + " " + empid);
	
	}
}



