package com.testing250.JavaDay3;

public class TC03_OverloadConst {
	
	
	public static void main(String[] args) {
		EmpConst obj=new EmpConst();
		
		obj.empnm="TestEmp";
		obj.empid=1123;
		
		System.out.println(obj.empnm+ " " + obj.empid);

		
		EmpConst obj1 = new EmpConst("tey",676);
		System.out.println(obj1.empnm+ " " + obj1.empid);
		
		
	}
	
public void dispayData1() {
		
	}



}


class EmpConst {
	
	String empnm;
	int empid;
	
	EmpConst(){
		empnm = "Athrija J";
		empid = 9989;
	}
	
	EmpConst(String nm , int id){
		this.empnm=nm;
		this.empid=id;
		
		
	}
	
	
	
	
	
}
