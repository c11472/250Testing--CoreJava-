package com.testing250.JavaDay3;

import java.util.Scanner;

public class TC02_ArrayOfObjects {
	public static void main(String[] args) {
		
		A obj [] = new A[5];
		Scanner c = new Scanner(System.in);
		
		
		
		
		
		for(int i=0;i<=2;i++) {
			int id=c.nextInt();
			
			
		}
		
		
	}

}
class A{
	int n;
	A(int n1){
		this.n=n1;
	}
}
