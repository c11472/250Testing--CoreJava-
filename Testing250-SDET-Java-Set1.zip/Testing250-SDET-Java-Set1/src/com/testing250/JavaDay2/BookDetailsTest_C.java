package com.testing250.JavaDay2;

public class BookDetailsTest_C {
	
	public static void main(String[] args) {
		
		// Object for BookDetails
		BookDetails obj = new BookDetails();
		
		// initialized data
		obj.Bookname="Let us Java";
		obj.BookPrice=977.90;
		obj.BookAuthor="YPK";
		obj.BookPages=675;
		
		System.out.print(obj.Bookname + " " +obj.BookPrice + " "+obj.BookAuthor + " "+obj.BookPages);
		

	}
}


class BookDetails{
	
	// class members
	
	String Bookname;
	double BookPrice;
	String BookAuthor;
	int BookPages;
	
	
	
}
