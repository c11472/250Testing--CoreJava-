package com.testing250.JavaDay2;

public class EmployeeDetailsTest {
	public static void main(String[] args) {
		
		EmployeeDetails obj = new EmployeeDetails();
		
		System.out.println(obj.EmpName); // testemp1
		
		System.out.println(obj.EmpId); //  1134
		
	}
}

class EmployeeDetails {
	
	String EmpName;
	int EmpId;
	
	
	// Constructor -- Initialize the class members
	EmployeeDetails(){
		EmpName = "testemp1";
		EmpId = 1134;	
	}
}
