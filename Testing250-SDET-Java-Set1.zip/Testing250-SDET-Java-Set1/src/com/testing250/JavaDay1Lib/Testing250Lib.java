package com.testing250.JavaDay1Lib;

import java.util.Arrays;
import java.util.List;

public class Testing250Lib {
	
	
	//Creating the tasks statements
	
	//Method SayHello
	
	// No return type and no parameters
	public void SayHello() {
		
		System.out.println("Hello World !");
		
	}
	
	// Method PrintNumber
	// No rturn type with param - int
	public void PrintNumber(int number) {
	
		System.out.println(number);
			
	}
	
	//Method ReverseString
	public String ReverseString(String reveseVal) {
		
		//String str1 = "HelloTest";
		StringBuffer sb = new StringBuffer(reveseVal);
		
		StringBuffer sb1= sb.reverse();
	    reveseVal  = sb1.toString();
		
		return reveseVal;
		
	}
	
	//Method GrossCalculate
	
	public double GrossCalculate(double sal) {
		
		double grossSal = sal+(sal*10/100);
		
		return grossSal;
		
	}
	
	//Method CalculateFactorial
	public void CalculateFactorial(int num1) {
		int fact = 1;
		for(int i=1;i<=num1;i++) {
			fact = fact*i;
			
		}
		System.out.println(fact); // fact val
		
	}
	
	public double CalculateareaOfCircle(double r, double pi) {
		double area = pi*r*r;
		
		return area;
	}
	// The method is having param array
	public int[] display(int arr[]) {
		
		return arr;
		
	}
	
	
	// Accepting List as parameterand returning List in method
	public List Data(List l) {
		
		int arr[] = {1,2,3,4,5,6,7};
		Arrays.asList(l);
		return l;
		
	}

    
}