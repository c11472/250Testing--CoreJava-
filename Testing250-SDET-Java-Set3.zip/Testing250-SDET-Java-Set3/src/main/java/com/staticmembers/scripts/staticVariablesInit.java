package com.staticmembers.scripts;

public class staticVariablesInit {
	
	
//	static int empid=10;
//	static String empname="testemp";
//	static double empsal=78000.00;
//	static float empval=(float) 90.5;
//	static char grade='P';
	
	public static void main(String[] args) {
		
		System.out.println(empid);
		System.out.println(empname);
		System.out.println(empsal);
	    System.out.println(empval);
		System.out.println(grade);
		System.out.println(staticVariablesInit.empname);
		
//		static int empid=10;
//		static String empname="testemp";
//		static double empsal=78000.00;
//		static float empval=(float) 90.5;
//		static char grade='P';

		
	}
	
	static int empid=10;
	static String empname="testemp";
	static double empsal=78000.00;
	static float empval=(float) 90.5;
	static char grade='P';

	

}
