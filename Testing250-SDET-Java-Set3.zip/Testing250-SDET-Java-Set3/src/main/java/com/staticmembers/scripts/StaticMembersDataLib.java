package com.staticmembers.scripts;

public class StaticMembersDataLib {
	// static variables
	static int empid=11472;
	static String empname="gayatri";
	static double empsal=0.00;
	static float empval=(float) 9.8;
	static char grade='O';
	
	static int arr[]= {1,2,3,4,5};
	
	
	// static methods
	
	static void PerformMyTask1() {
		
		int num=10;
		System.out.println(num+"task1");
		
	}
	
	static int PerformMyTask2(int p) {
	   
		return p;
		
	}
	
	static String PerformMyTask3(String name) {
		return name;
	
	}
	

}
