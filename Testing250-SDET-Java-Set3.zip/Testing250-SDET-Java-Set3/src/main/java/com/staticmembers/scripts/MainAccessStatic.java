package com.staticmembers.scripts;


public class MainAccessStatic {
	
	public static void main(String[] args) {
		
		System.out.println(StaticMembersDataLib.empname);
		// Access static methods
		
		StaticMembersDataLib.PerformMyTask1();
		
		int resstatic = StaticMembersDataLib.PerformMyTask2(100);
		
		System.out.println(resstatic);
		
		String result = StaticMembersDataLib.PerformMyTask3("QA Test Eng");
		System.out.println(result);
		
		for(int i:StaticMembersDataLib.arr) {
			System.out.print(i+ " ");
		}
		
		
		
		
		
	}

}
