package com.staticmembers.scripts;

public class StaticBlockTest {
	
	
	static {
		
		System.out.println("Enjoying Java Coding !");
		System.out.println("Going to Mumbai !");
	}
	
static {
		
		System.out.println("Enjoying Java Coding12 !");
		System.out.println("Going to Mumbai56 !");
	}
	
	public static void main(String[] args) {
		System.out.println("This is the main block !");
	
	}

}
