package com.staticmembers.scripts;

public class StaticVariablesDemo {
	static int empid;
	static String empname;
	static double empsal;
	static float empval;
	static char grade;
	
	public static void main(String[] args) {
		
		System.out.println(empid);
		System.out.println(empname);
		System.out.println(empsal);
		System.out.println(empval);
		System.out.println(grade);
		
	}
	

}
