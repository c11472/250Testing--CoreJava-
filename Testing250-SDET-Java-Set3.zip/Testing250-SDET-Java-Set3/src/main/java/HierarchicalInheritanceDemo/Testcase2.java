package HierarchicalInheritanceDemo;

public class Testcase2 extends BaseResource{
	
	public void GetDataFromTestcase2() {
		Testcase2 bsrc = new Testcase2();
		
		System.out.println(bsrc.path);
		System.out.println(bsrc.BrowsetName);
		System.out.println(bsrc.pompath);
	}
	

}
