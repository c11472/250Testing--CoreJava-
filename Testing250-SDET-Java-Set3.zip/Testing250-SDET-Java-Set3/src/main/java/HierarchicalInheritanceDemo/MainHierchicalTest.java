package HierarchicalInheritanceDemo;

public class MainHierchicalTest {
	
	public static void main(String[] args) {
		Testcase1 t1 = new Testcase1();
		Testcase2 t2 = new Testcase2();
		t1.GetDataFromTestcae1();
		t2.GetDataFromTestcase2();	
	}

}
