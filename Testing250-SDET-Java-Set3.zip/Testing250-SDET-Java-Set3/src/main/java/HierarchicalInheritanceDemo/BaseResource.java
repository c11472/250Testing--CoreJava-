package HierarchicalInheritanceDemo;

public class BaseResource {
	String path;
	String BrowsetName;
	String pompath;
	BaseResource(){
		path = "config file path";
	    BrowsetName = "Chrome";
		pompath = "C:/testdata/test.xml";
	}

}
