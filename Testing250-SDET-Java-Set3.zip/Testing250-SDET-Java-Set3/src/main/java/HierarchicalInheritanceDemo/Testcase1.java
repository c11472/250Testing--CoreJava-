package HierarchicalInheritanceDemo;

public class Testcase1 extends BaseResource {
	//BaseResource bsrc = new BaseResource();
	public void GetDataFromTestcae1() {
		 Testcase1 bsrc1 = new  Testcase1();
		
		System.out.println(bsrc1.path);
		System.out.println(bsrc1.BrowsetName);
		System.out.println(bsrc1.pompath);
		
	}

}
