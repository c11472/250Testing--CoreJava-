import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UpdateTable {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {

		// JDBC connection parameters
		String url = "jdbc:mysql://localhost:3306/dbs1";
		String username = "root";
		String password = "P2ssw0rd@123";

		// JDBC objects
		PreparedStatement ps = null;

		// try {
		// Load the JDBC driver
		Class.forName("com.mysql.jdbc.Driver");
		
		//Connection
		
		Connection connection = DriverManager.getConnection(url, username, password);

		// SQL query to update data in the table
		String sql = " update course set courseid = ? where courseid=?";

		// Create a prepared statement
		ps = connection.prepareStatement(sql);

		// Set new values for the columns
		ps.setInt(1, 1564);
		ps.setInt(2, 104);
       
		// Execute the query
		int rowsAffected = ps.executeUpdate(); 
		System.out.println(rowsAffected); // 1
		
		if(rowsAffected>0) {
			System.out.println("Data updated successfully");
		}
		else {
			System.out.println("NA");
		}

				
		
		
	}

}
