package com.JDBCLibTestMethods.JDBCTest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBC_TestMethods  {
	JDBC_TestMethods() throws ClassNotFoundException, SQLException {
		super();
		// TODO Auto-generated constructor stub
	}

	public String TestMySQLConnction() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/dbs1", "root", "P2ssw0rd@123");
	    Object connecttest = con;
	    System.out.println(connecttest);
	    
	    String conVal = connecttest.toString();
	    //System.out.println("Con val in string format" + conVal);
	    
	   /* if(conVal.contains("@609e8838")) {
	    	System.out.println("The connection is established ");
	    }
	    
	    else {
	    	System.out.println("pls check the conf info");
	    }*/
	    return conVal;
	}
	
	public void CreateATableIndbs1() throws SQLException {
		Connection connection = null;
		Statement statement = null;

		// Establish the connection
		Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost/dbs1", "root", "P2ssw0rd@123");

		// Create a Statement object
		statement = con1.createStatement();

		// Define the SQL statement to create a table
		String createTableSQL = "create table Alice(AliceLastName varchar(20))";
	//	String describeTable = "select * from testtab8;";


		// Execute the SQL statement
		statement.executeUpdate(createTableSQL);
		
		System.out.println("The table Alice created successfully in dbs1 ");
		

	}
	
	
	public void InsertRecordsIntoTable() throws SQLException, ClassNotFoundException {
		// Load the JDBC driver
		Class.forName("com.mysql.jdbc.Driver");
		
		PreparedStatement pst = null;


		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/dbs1", "root", "P2ssw0rd@123");

		String sql = "insert into Alice(AliceLastName) VALUES (?)";

		// Create a prepared statement
		pst = connection.prepareStatement(sql);
		
		//pst.setString(1, "NewTestData");
		pst.setString(1, "NewTestData1");
		pst.setString(1, "NewTestData2");
		// Execute the query
		int rowsAffected = pst.executeUpdate();
		System.out.println(rowsAffected);
	}
	
	
	public void ExtractDataFromTable() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");

		// To establish the connection <--- inteface
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbs1", "root", "P2ssw0rd@123");
		String myquery = "select * from course order by courseid;";

		// Prepared statement instance for query <--- Interface

		// change the query as per your table
		System.out.println(con);
		PreparedStatement stmt = con.prepareStatement(myquery);

		// Resultset will hold the result <---- Interface
		
		ResultSet rs = stmt.executeQuery();
		/*rs.getnt
		rs.getString
		rs.getDouble
		rs.getFloat*/
		

		// Traverse the ResultSet rs to display the output of the query in console
		while (rs.next()) {
			System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getInt(3));
		}
		

	}
	
	
	
	// Update Table
	
	public void UpdateDataInTable() throws SQLException, ClassNotFoundException {
		String url = "jdbc:mysql://localhost:3306/dbs1";
		String username = "root";
		String password = "P2ssw0rd@123";

		// JDBC objects
		PreparedStatement ps = null;

		// try {
		// Load the JDBC driver
		Class.forName("com.mysql.jdbc.Driver");
		
		//Connection
		
		Connection connection = DriverManager.getConnection(url, username, password);

		// SQL query to update data in the table
		String sql = " update course set courseid = ? where courseid=?";

		// Create a prepared statement
		ps = connection.prepareStatement(sql);

		// Set new values for the columns
		ps.setInt(1, 1944);
		ps.setInt(2, 101);
       
		// Execute the query
		int rowsAffected = ps.executeUpdate(); 
		System.out.println(rowsAffected); // 1
		
		if(rowsAffected>0) {
			System.out.println("Data updated successfully");
		}
		else {
			System.out.println("NA");
		}


	}

}
