package com.JDBCLibTestMethods.JDBCTest;
import java.sql.SQLException;
public class JdbxcRunner {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		JDBC_TestMethods jdbcTest = new JDBC_TestMethods();
		String conval1=jdbcTest.TestMySQLConnction();
		System.out.println("Connection value " + " " + conval1);
		//jdbcTest.CreateATableIndbs1();
		//jdbcTest.InsertRecordsIntoTable();
		//jdbcTest.ExtractDataFromTable();
		
		//jdbcTest.UpdateDataInTable();
		
		
	}
}
