package MethodOverridingDemo;

public class MainTest {
	public static void main(String[] args) {
		
		
		BookDetails obj = new AutherDetails();
		obj.DisplayBookDetails();
		
		
		
	}

}
