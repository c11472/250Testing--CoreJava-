package MethodOverridingDemo;

public class BookDetails {
	
	String BookName;
	double BookPrice;
	
	BookDetails(){
		
		BookName = "Let us C";
		BookPrice = 900.00;
		
	}
	// Method
	public void DisplayBookDetails() {
		System.out.println(BookName+ " " + BookName);
	}
	
	

}
