package MethodOverridingDemo;

public class AutherDetails  extends BookDetails{
	
	public void DisplayBookDetails() {
		System.out.println("This is the second class");
	}
	
	

}
