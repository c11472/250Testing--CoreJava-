package Testing250_SDET_Java_Set2.Testing250_SDET_Java_Set2;

public class TestScript001 {
	public static void main(String[] args) {
		
		B o1 = new B();
		B o2 = new B("test");
		
	}

}

class A {
	int a;
	String b;
	A(){
		a=10;
		System.out.println(a);
		
	}
	
	A(String b1){
		this.b=b1;
		System.out.println(b);
		
	}	
}
class B extends A{
	B(){
		super();
	}
	
	B(String b1){
		super(b1);
		
	}
	
	
}