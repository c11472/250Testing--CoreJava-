package com.bank.base;

public class BankBase {
    String BankName;
    String BankIFSC;
    String BankLoc;
   public  int Bankid=198765;
    
    
    protected BankBase(String BankName,String BankIFSC,String BankLoc){
    	this.BankName=BankName;
    	this.BankIFSC=BankIFSC;
    	this.BankLoc=BankLoc;
    }
    
    
    public void DisplayBankDetails() {
    	System.out.println(BankName + " " + BankIFSC + " "+BankLoc);
    }
    
}
