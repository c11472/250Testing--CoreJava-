package com.bank.scripttorun;

import com.bank.derived.ATM;

public class TestBankRun {
	public static void main(String[] args) {
		ATM atm = new ATM("ICICI", "ICI9878", "BBS-1");
		ATM atm1 = new ATM("ICICI-1", "ICI9879", "BBS-2");

		
		atm.ATMAddr();
		atm.DisplayBankDetails();
		int result=atm.ExtractBankID();
		System.out.println("The bank id is : " + " " + result);
		atm1.DisplayBankDetails();
		
	}
	
	
	
	

}
