package com.bank.derived;

import com.bank.base.BankBase;

public class ATM extends BankBase {

	public ATM(String BankName, String BankIFSC, String BankLoc) {
		super(BankName, BankIFSC, BankLoc);
		
	}
	
	public void InvokeMethod() {
		super.DisplayBankDetails();
	}
	
	public void ATMAddr() {
		System.out.println("BBSR-OD5");
		
	
		
	}
	
	public int ExtractBankID() {
		
		int 
		bid = super.Bankid;
		return bid;
		
		
		
		
	}
	
	
	

	
}
