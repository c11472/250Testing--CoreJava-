package Multilevel_EmployeeDetails;

public class EmpBase {
	
	String EmpName;
	String DeptName;
	double EmpSal;
	int Empid;
	
	EmpBase(String enm){
		this.EmpName=enm;
		
	}
	
	public void AccessEmpName() {
		System.out.println(EmpName);
	}
	
	public void AccessEmployeeID() {
		Empid = 8976;
		System.out.println("Employee Id is" + Empid  );
		
	}

}
