package Multilevel_EmployeeDetails;

import java.util.Scanner;

class DeptData extends EmpBase {
    String DeptName;
	DeptData(String enm) {
		super(enm);
	}
	
	public void deptNameDisplay() {
		Scanner c = new Scanner(System.in);
		System.out.println("Enter your department name : ");
		DeptName = c.nextLine();
		System.out.println("The dept name is: " +DeptName );
	}
	
	
}
