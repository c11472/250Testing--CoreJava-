package Multilevel_EmployeeDetails;

public class ExecuteMain {
	public static void main(String[] args) {
		
		SalaryDetails sal = new SalaryDetails("675675");
		
		sal.AccessEmpName();
		sal.deptNameDisplay();
		
		sal.AccessEmployeeID();
		
	}

}
