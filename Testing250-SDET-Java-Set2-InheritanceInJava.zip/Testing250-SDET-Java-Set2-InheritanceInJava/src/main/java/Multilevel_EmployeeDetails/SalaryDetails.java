package Multilevel_EmployeeDetails;

public class SalaryDetails extends DeptData {

	SalaryDetails(String enm) {
		super(enm);
		// TODO Auto-generated constructor stub
	}

}
