package Testing250_SDET_Java_Set6_Encapsulation.Testing250_SDET_Java_Set6_Encapsulation;

import java.util.Scanner;

public class AccessEmployeeData {
	public static void main(String[] args) {
		
		Scanner c = new Scanner(System.in);
		int arr[] = {1,2,3,4,5,6,7,8,9,10};
		// Create Object
		EmpData data = new EmpData();
		// set EmpName
		System.out.println("Enter the EmployeeName");
		data.Set_EmpName(c.nextLine());
		
		// get EmpName
		
		String enm=data.Get_EmployeeName();
		System.out.println(enm);
		
		data.Set_EmpId(1090);
		int empid= data.Get_EmpId();
		System.out.println("Employee is :" + empid);
		
		data.Set_EmpSal(78000.90);
		double sal = data.Get_EmpSal();
		System.out.println("Employee sal :" + sal);
		
		data.Set_empGrade('A');
		char grade1 = data.Get_empGrade();
		System.out.println("grade is :" + grade1);
		
		data.set_arr(arr);
		
		int brr[] = data.get_arr();
		
		for(int i:brr) {
			System.out.println(i+ " ");
		}
		
	}

}
