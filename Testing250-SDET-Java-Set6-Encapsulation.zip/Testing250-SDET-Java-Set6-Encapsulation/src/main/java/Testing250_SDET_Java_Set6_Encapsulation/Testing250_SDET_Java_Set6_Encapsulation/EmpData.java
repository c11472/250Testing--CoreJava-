package Testing250_SDET_Java_Set6_Encapsulation.Testing250_SDET_Java_Set6_Encapsulation;

public class EmpData {
	
	private String EmpName;
	private int EmpId;
	private double EmpSal;
	private char empGrade;
	
	private int arr[];
	
	
	// Define all the setter methods
	// used for seting the data for the private member
	// setter methods must not return any thing - void
	// setter method must be parameterized
	
	public void Set_EmpName(String EmpName) {
		this.EmpName=EmpName;
		
	}
	
	
	public String Get_EmployeeName() {
		return EmpName;
		
	}
	
	public void Set_EmpId(int EmpId) {
		this.EmpId=EmpId;
		
	}
	
	public int Get_EmpId() {
		return EmpId;
	}
	
	public void Set_EmpSal(double EmpSal) {
		this.EmpSal=EmpSal;
		
	}
	
	public double Get_EmpSal() {
		return EmpSal;
	}
	
	public void Set_empGrade(char empGrade) {
		this.empGrade=empGrade;
		
	}
	
	public char Get_empGrade() {
		return empGrade;
	}
	
	public void set_arr(int[] arr) {
		this.arr=arr;
		
		
	}
	
	public int[] get_arr() {
		return arr;
		
	}

}

