package Testing250_SDET_Java_Set6_Encapsulation.Testing250_SDET_Java_Set6_Encapsulation;

public class SetData {
	private int p;
	private double val;
	private int test[];
	
	
	public void set(int p) {
		this.p=p;
	}
	
	public int get() {
		return p;
	}
	public void setnum(int test[]) {
		this.test=test;
	}
	
	public int[] getNum() {
		return test;
	}
	public static void main(String[] args) {
	

		SetData obj = new SetData();
		obj.set(10);
		System.out.println(obj.get());
		obj.setnum(new int[] {1,2,3,4,56});
		int arr[]=obj.getNum();
		for(int i:arr) {
			System.out.print(i+ " ");
		}
		
		
	}

	

}
